export class Meilisearch {}
