import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Request } from 'express';
import { Observable } from 'rxjs';
import { UserRepository } from 'src/user/repo/user';
import { UserRoles } from '../enum';
import { CourseRepository } from 'src/learning/course/infrastructure/persistence/sequelize/course.repo';

type properties = {
  courseId: number;
  id: number;
};
@Injectable()
export class OwnerCourse implements CanActivate {
  constructor(
    private readonly userRepository: UserRepository,
    private readonly courseRepo: CourseRepository,
  ) {}
  async canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest() as Request<properties>;

    const { courseId, id: userId } = req.params;

    if (!courseId || !userId)
      throw new NotFoundException('some params not found');

    const owner = await this.courseRepo.ownerCourse(userId, courseId);

    if (!owner) throw new NotFoundException('user or course not found');

    if (!owner) throw new ForbiddenException('not allowed for you');

    return true;
  }
}
