export function TransformToArray(value: unknown) {
  if (typeof value === 'undefined') return [];

  if (typeof value === 'string') {
    const parsed = JSON.parse(value);
    Array.isArray(parsed) ? parsed : [parsed];
  }

  if (typeof value === 'object') return [value];

  return [];
}
