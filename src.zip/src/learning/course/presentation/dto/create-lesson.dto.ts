export class CreateLessonDto {}
