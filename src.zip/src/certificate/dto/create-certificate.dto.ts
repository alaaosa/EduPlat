export class CreateCertificateDto {}
