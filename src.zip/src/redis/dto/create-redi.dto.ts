export class CreateRediDto {}
